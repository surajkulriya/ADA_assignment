# ADA_assignment
Algorithm design and analysis course assignments

Executing the files
-------------------
For every que you want to evaluate, just run command 
    './checkque --que\<number\>'

For instance you want to evaluate que3, run command 
    './checkque --que3'

If you want to evaluate que6a, run command 
    './checkque --que6a'

Run command 
    './checkque --clean'
to remove all the binary files.

You can also run command 
    "g++ -o main que3.cpp && ./main"
if yor are familiar with CPP language.

Thanks
